#include <16f877a.h>
#fuses HS,NOWDT,NOPROTECT,PUT,NOLVP,NOBROWNOUT
#use delay(clock=20M)
#use I2C(MASTER, SDA=PIN_C4, SCL=PIN_C3, FAST)

#define ADDRESS_LCD 0x4E
#include <LCD_I2C.c>                   // Libreria de la pantalla LCD con modulo I2C

int contador = 0;

char figura_1[8] = {0x04,0x11,0x0E,0x04,0x04,0x0A,0x11,0x00};
char figura_2[8] = {0x04,0x00,0x0E,0x15,0x04,0x0A,0x11,0x00};

void main()
{
  lcd_init();                          // Inicializa la pantalla LCD
  CGRAM_position(0);                   // Selecciona la posicion de la CGRAM
  CGRAM_create_char(figura_1);         // Guarda caracter especial en la posicion 0
  CGRAM_position(1);                   // Selecciona la posicion de la CGRAM
  CGRAM_create_char(figura_2);         // Guarda caracter especial en la posicion 1
  
  while(true)
  {
    lcd_gotoxy(1,1);                   // Columna 1, Fila 1
    lcd_putc("Contador");
    lcd_gotoxy(1,2);                   // Columna 1, Fila 2
    printf(lcd_putc, "%u", contador);  // Imprime el valor del contador en la LCD
    lcd_gotoxy(15,2);                  // Columna 15, Fila 2
    CGRAM_putc(0);                     // Imprime el caracter especial guardado en la posicion 0
    delay_ms(300);
    lcd_gotoxy(15,2);                  // Columna 15, Fila 2
    CGRAM_putc(1);                     // Imprime el caracter especial guardado en la posicion 1
    contador++;                        // Incrementa el contador
    delay_ms(300);
    lcd_clear();                       // Limpia la pantalla LCD
  }
}
