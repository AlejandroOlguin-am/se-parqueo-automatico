/* #include <LCD_I2C.c>
*
* Creada por: Ing. Abiezer Hernandez O.
* Fecha de creacion: 17/04/2020
* Electronica y Circuitos
*
*/

void lcd_cmd(int8 cmd)
{
   int8 data_u, data_l;
   data_u = (cmd & 0xF0);
   data_l = ((cmd<<4) & 0xF0);
   i2c_start();
   i2c_write(ADDRESS_LCD);
   i2c_write(data_u|0x0C);
   i2c_write(data_u|0x08);
   i2c_write(data_l|0x0C);
   i2c_write(data_l|0x08);
   i2c_stop();
}

void lcd_char(char data)
{
   int8 data_u, data_l;
   data_u = (data & 0xF0);
   data_l = ((data<<4) & 0xF0);
   i2c_start();
   i2c_write(ADDRESS_LCD);
   i2c_write(data_u|0x0D);
   i2c_write(data_u|0x09);
   i2c_write(data_l|0x0D);
   i2c_write(data_l|0x09);
   i2c_stop();
}

void lcd_init(void)
{
   delay_ms(50);
   lcd_cmd(0x30);
   delay_ms(5);
   lcd_cmd(0x30);
   delay_ms(1);
   lcd_cmd(0x30);
   delay_ms(10);
   lcd_cmd(0x20);
   delay_ms(10);
   lcd_cmd(0x28);
   delay_ms(1);
   lcd_cmd(0x08);
   delay_ms(1);
   lcd_cmd(0x01);
   delay_ms(2);
   lcd_cmd(0x06);
   delay_ms(1);
   lcd_cmd(0x0C);
   delay_ms(1);
   lcd_cmd(0x01);
   delay_ms(2);
}

void lcd_clear(void)
{
   lcd_cmd(0x01);
   delay_ms(2);
}

void lcd_gotoxy(int x, int y)
{
   int8 address;
   switch(y)
   {
      case 1:
         address = 0x00;
         break;
      case 2:
         address = 0x40;
         break;
      case 3:
         address = 0x14;
         break;
      case 4:
         address = 0x54;
         break;
   }
   address += x - 1;
   lcd_cmd(0x80 | address);

}

void lcd_putc(char c)
{
   lcd_char(c);
}

void CGRAM_putc(int8 n)
{
   lcd_char(n);
}

void CGRAM_position(int8 p)
{
   lcd_cmd(0x40+p*8);
}

void CGRAM_create_char(char* new_char)
{
   for(char cg=0; cg<8; cg++)
   {
      lcd_char(new_char[cg]);
   }
}
